import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { MatDialog } from '@angular/material';
import { InformationComponent } from '../information/information.component';

@Component({
  selector: 'app-registration-component',
  templateUrl: './registration-component.component.html',
  styleUrls: ['./registration-component.component.css']
})
export class RegistrationComponentComponent implements OnInit {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  Status: string;
  AccStatus: string;
  isError: boolean;
  errorMessage: any;

  constructor(public authenticationService:AuthenticationService,public dialog: MatDialog) { }

  ngOnInit() {
  }

  register() {

    if(this.validateRegistration()){
      const dialogRef = this.dialog.open(InformationComponent, {
        width: '250px',
        data: {message :'Please fill all the details and register!'}
      });
      this.isError = true;
      this.errorMessage = 'Please fill all the details and register!'
    }
    this.authenticationService.SignUp(this.email, this.password);
    this.email = ''; 
    this.password = '';
    
  }

  public validateRegistration(){
    if(this.firstName ===undefined || this.lastName ===undefined||this.email ===undefined||
       this.password ===undefined || this.Status ===undefined||this.AccStatus ===undefined ){
      return true;
    }
    return false;
  }
  
  signOut() {
    this.authenticationService.SignOut();
  }

}
