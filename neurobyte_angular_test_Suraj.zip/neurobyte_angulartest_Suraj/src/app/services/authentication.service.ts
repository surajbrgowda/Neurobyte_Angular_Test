import { Injectable } from '@angular/core';
import { AngularFireAuth } from "@angular/fire/auth";
import { Observable } from 'rxjs';
import { MatDialog } from '@angular/material';
import { InformationComponent } from '../information/information.component';

@Injectable({
  providedIn: 'root'
})

export class AuthenticationService {
  userData: Observable<firebase.User>;
  hasError: any;

  constructor(private angularFireAuth: AngularFireAuth,public dialog: MatDialog) {
    this.userData = angularFireAuth.authState;
  }

  /* Sign up */
  SignUp(email: string, password: string) {
    this.angularFireAuth
      .auth
      .createUserWithEmailAndPassword(email, password)
      .then(res => {
        console.log('You are Successfully signed up!', res);
      })
      .catch(error => {
        console.log('Something is wrong:', error.message);
        this.hasError =error.message;
        const dialogRef = this.dialog.open(InformationComponent, {
          width: '250px',
          data: {message :error.message}
        });
      });    
  }

  /* Sign in */
  SignIn(email: string, password: string) {
    this.angularFireAuth
      .auth
      .signInWithEmailAndPassword(email, password)
      .then(res => {
        console.log('You are Successfully logged in!');
        const dialogRef = this.dialog.open(InformationComponent, {
          width: '250px',
          data: {message :'You are Successfully logged in!'}
        });
      })
      .catch(error => {
        console.log('Something is wrong:',error.message);
        const dialogRef = this.dialog.open(InformationComponent, {
          width: '250px',
          data: {message :error.message}
        });
      });
  }

  /* Sign out */
  SignOut() {
    this.angularFireAuth
      .auth
      .signOut();
  }  

}