import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { MatDialog } from '@angular/material';
import { InformationComponent } from '../information/information.component';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {
  email: string;
  password: string;
  constructor(public authenticationService:AuthenticationService,public dialog: MatDialog) { }

  ngOnInit() {
  }

  signIn() {
    if(this.validateLogin()){
      const dialogRef = this.dialog.open(InformationComponent, {
        width: '250px',
        data: {message :'Please fill all the details and login!'}
      });
    }
    this.authenticationService.SignIn(this.email, this.password);
    this.email = ''; 
    this.password = '';
  }

  validateLogin(){
    if(this.email === undefined || this.password=== undefined){
    return true;
  }
    return false;
  }

  signOut() {
    this.authenticationService.SignOut();
  }

}
