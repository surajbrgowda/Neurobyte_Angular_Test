// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyBMuQH7LVRaiTj0H6rc1ETBCkcE5KylPTw",
    authDomain: "neurobyte-management-of-users.firebaseapp.com",
    databaseURL: "https://neurobyte-management-of-users.firebaseio.com",
    projectId: "neurobyte-management-of-users",
    storageBucket: "neurobyte-management-of-users.appspot.com",
    messagingSenderId: "530379791832",
    appId: "1:530379791832:web:ae2a76aef618dee42826ad",
    measurementId: "G-ZBQH2DQVL5"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
